/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author kianjun
 */
public class Constant {
    public static String SystemName = "APU Automotive Service Centre (AASC)";
    public static String Dashboard = "Dashboard";
    public static String LoginAs = "LOGGED IN AS";
    public static String ManageTechnician = "Manage Technician";
    public static String ManageCustomer = "Manage Customer";
    public static String ManageCategory = "Manage Category";
    public static String ManageProduct = "Manage Product";
    public static String LogReport = "Log Report";
    public static String Profile = "Profile";
    public static String PROFILE = "PROFILE";
    public static String AddNewCustomer = "Add New Customer";
    public static String AddNewTechnician = "Add New Technician";
    public static String Username = "Username";
    public static String Password = "Password";
    public static String AddNewManager = "Add New Manager";
    public static String Security = "Security";
    public static String Question = "Security Question";
    public static String Answer = "Security Answer";
    public static String Manager = "MANAGER";
    public static String Technician = "TECHNICIAN";
    public static String UpdateCategory = "Update Category";
    public static String UpdateTechnician = "Update Technician";
    public static String ViewCustomerDatabase = "View Customer Database";
    public static String CleanDatabase = "Clean Database";
    public static String Appointment = "Manage Appointment";
    public static String UpdateCustomer = "Update Customer";
    public static String AddPayment = "Add Payment";
    public static String PaymentMethod = "Select Payment Method";
    public static String MakeFeedback = "Make a Feedback";
    public static String ViewAppointment = "View Appointment";
    public static String ViewFeedback = "View Feedback";
    public static String ViewPayment = "View Payment";
    public static String ViewPaymentDatabase = "View Payment Database";
    public static String AddCustomer = "Add a new customer";
    public static String ViewRevenue = "View Sales Revenue";
    public static String ViewFeedbackDatabase = "View Feedback Database";
    public static String ViewAppointmentDatabase = "View Appointment Database";
    public static String UpdateAppointment = "Update Appointment";
}
