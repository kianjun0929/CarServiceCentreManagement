/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helpsclass;

import java.util.ArrayList;

/**
 *
 * @author kianjun
 */
public class Utils {
    
    public static ArrayList<String> filter( ArrayList<String> dat, int constranit ){
        ArrayList<String> newList = null;
        
        return newList;
    }
    
}
